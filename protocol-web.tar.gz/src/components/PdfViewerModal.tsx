import React, { useState, useRef, useEffect, useLayoutEffect, useCallback } from "react";
import {
  Download,
  CloudUpload,
  X,
  FileCheck,
  PenTool,
  Eraser,
  Undo2,
  Trash2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Hand,
  Check,
  Loader2,
  FileText,
} from "lucide-react";
import * as pdfjsLib from "pdfjs-dist";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import { PDFDocument } from "pdf-lib";

// Set PDF.js worker URL
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

interface PdfViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  pdfBase64: string | null;
  onDownload: (signedBase64?: string) => void;
  onExportDocx?: () => void;
  onUpload: (signedBase64?: string) => void;
  isSaving: boolean;
  compilerUsed: string;
}

type ToolMode = "view" | "pen" | "eraser";

interface NormalizedPoint {
  nx: number;
  ny: number;
}

interface Stroke {
  points: NormalizedPoint[];
  color: string;
  widthRatio: number;
  isEraser?: boolean;
}

const PEN_COLORS = [
  { id: "blue", hex: "#1d4ed8", label: "Dokumentenblau" },
  { id: "black", hex: "#09090b", label: "Schwarz" },
  { id: "purple", hex: "#4a227a", label: "JA-Violett" },
  { id: "red", hex: "#dc2626", label: "Rot" },
];

const STROKE_WIDTHS = [
  { id: "thin", value: 1.8, label: "Fein" },
  { id: "normal", value: 3.2, label: "Mittel" },
  { id: "thick", value: 5.5, label: "Breit" },
];

// High-precision smooth stroke renderer on any canvas
const renderStrokesToCanvas = (
  ctx: CanvasRenderingContext2D,
  strokes: Stroke[],
  canvasWidth: number,
  canvasHeight: number
) => {
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  for (const stroke of strokes) {
    if (stroke.points.length === 0) continue;

    const baseWidth = stroke.widthRatio * canvasWidth;
    ctx.beginPath();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (stroke.isEraser) {
      ctx.globalCompositeOperation = "destination-out";
      ctx.lineWidth = baseWidth * 4;
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = baseWidth;
    }

    const first = stroke.points[0];
    const firstX = first.nx * canvasWidth;
    const firstY = first.ny * canvasHeight;

    if (stroke.points.length === 1) {
      ctx.arc(
        firstX,
        firstY,
        (stroke.isEraser ? baseWidth * 2 : baseWidth) / 2,
        0,
        Math.PI * 2
      );
      ctx.fillStyle = stroke.color;
      ctx.fill();
    } else if (stroke.points.length === 2) {
      const second = stroke.points[1];
      ctx.moveTo(firstX, firstY);
      ctx.lineTo(second.nx * canvasWidth, second.ny * canvasHeight);
      ctx.stroke();
    } else {
      ctx.moveTo(firstX, firstY);
      for (let i = 1; i < stroke.points.length - 1; i++) {
        const p1 = stroke.points[i];
        const p2 = stroke.points[i + 1];
        const p1x = p1.nx * canvasWidth;
        const p1y = p1.ny * canvasHeight;
        const p2x = p2.nx * canvasWidth;
        const p2y = p2.ny * canvasHeight;
        const midX = (p1x + p2x) / 2;
        const midY = (p1y + p2y) / 2;
        ctx.quadraticCurveTo(p1x, p1y, midX, midY);
      }
      const last = stroke.points[stroke.points.length - 1];
      ctx.lineTo(last.nx * canvasWidth, last.ny * canvasHeight);
      ctx.stroke();
    }
  }
  ctx.globalCompositeOperation = "source-over";
};

export const PdfViewerModal: React.FC<PdfViewerModalProps> = ({
  isOpen,
  onClose,
  pdfBase64,
  onDownload,
  onExportDocx,
  onUpload,
  isSaving,
  compilerUsed,
}) => {
  const [numPages, setNumPages] = useState<number>(0);
  const [isLoadingPdf, setIsLoadingPdf] = useState<boolean>(true);
  const [pageDimensions, setPageDimensions] = useState<Record<number, { width: number; height: number }>>({});
  const [zoomScale, setZoomScale] = useState<number>(() => {
    if (typeof window !== "undefined" && window.innerWidth < 640) {
      return Math.max(0.45, Math.min(0.85, (window.innerWidth - 32) / 595));
    }
    return 1.15;
  });
  const [toolMode, setToolMode] = useState<ToolMode>("view");
  const [penColor, setPenColor] = useState<string>("#1d4ed8");
  const [strokeWidth, setStrokeWidth] = useState<number>(3.2);
  const [pageStrokes, setPageStrokes] = useState<Record<number, Stroke[]>>({});
  const pageStrokesRef = useRef<Record<number, Stroke[]>>({});
  const [isProcessingSave, setIsProcessingSave] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const pdfDocRef = useRef<any>(null);
  const lastLoadedPdfRef = useRef<string | null>(null);
  const pendingScrollRef = useRef<{ scrollLeft: number; scrollTop: number } | null>(null);
  const pageCanvasesRef = useRef<Record<number, HTMLCanvasElement | null>>({});
  const drawingCanvasesRef = useRef<Record<number, HTMLCanvasElement | null>>({});
  const currentStrokeRef = useRef<{ pageNum: number; stroke: Stroke } | null>(null);
  const isDrawingRef = useRef<boolean>(false);

  // Pages wrapper ref for smooth GPU scaling without canvas flashing
  const pagesWrapperRef = useRef<HTMLDivElement | null>(null);

  // Post-gesture commit data for useLayoutEffect
  const pendingPinchCommitRef = useRef<{
    localX: number;
    localY: number;
    ratio: number;
    midInContainerX: number;
    midInContainerY: number;
  } | null>(null);

  // Avoid accidental stroke or jump immediately after lifting 2 fingers
  const lastPinchEndTimeRef = useRef<number>(0);

  // Mouse drag-to-pan in view mode (DESKTOP ONLY)
  const isMousePanningRef = useRef<boolean>(false);
  const mousePanStartRef = useRef<{ x: number; y: number; scrollLeft: number; scrollTop: number }>({
    x: 0,
    y: 0,
    scrollLeft: 0,
    scrollTop: 0,
  });

  // Seamlessly apply scroll adjustments right after layout calculation
  useLayoutEffect(() => {
    if (!containerRef.current || !pagesWrapperRef.current) return;
    const container = containerRef.current;
    const wrapper = pagesWrapperRef.current;

    if (pendingPinchCommitRef.current) {
      const { localX, localY, ratio, midInContainerX, midInContainerY } = pendingPinchCommitRef.current;
      pendingPinchCommitRef.current = null;

      // Clear GPU transform now that DOM has rendered at the new zoomScale
      wrapper.style.transform = "";
      wrapper.style.transformOrigin = "";

      const rectW = wrapper.getBoundingClientRect();
      const rectC = container.getBoundingClientRect();
      const wrapperScrollX = rectW.left - rectC.left + container.scrollLeft;
      const wrapperScrollY = rectW.top - rectC.top + container.scrollTop;

      const newLocalX = localX * ratio;
      const newLocalY = localY * ratio;

      const targetScrollLeft = wrapperScrollX + newLocalX - midInContainerX;
      const targetScrollTop = wrapperScrollY + newLocalY - midInContainerY;

      container.scrollLeft = Math.max(0, targetScrollLeft);
      container.scrollTop = Math.max(0, targetScrollTop);
    } else if (pendingScrollRef.current) {
      container.scrollLeft = pendingScrollRef.current.scrollLeft;
      container.scrollTop = pendingScrollRef.current.scrollTop;
      pendingScrollRef.current = null;
    }
  }, [zoomScale, pageDimensions]);

  // Mouse drag-to-pan in view mode (Desktop only)
  const handleContainerPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (toolMode !== "view") return;
    if (e.pointerType !== "mouse") return; // Touch devices scroll natively!
    if ((e.target as HTMLElement).closest("button, input, select")) return;

    isMousePanningRef.current = true;
    mousePanStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      scrollLeft: containerRef.current?.scrollLeft || 0,
      scrollTop: containerRef.current?.scrollTop || 0,
    };
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
  };

  const handleContainerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isMousePanningRef.current || e.pointerType !== "mouse" || !containerRef.current) return;
    const dx = e.clientX - mousePanStartRef.current.x;
    const dy = e.clientY - mousePanStartRef.current.y;
    containerRef.current.scrollLeft = mousePanStartRef.current.scrollLeft - dx;
    containerRef.current.scrollTop = mousePanStartRef.current.scrollTop - dy;
  };

  const handleContainerPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "mouse" && isMousePanningRef.current) {
      isMousePanningRef.current = false;
      try {
        (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  // Smooth discrete zoom steps (for + / - buttons) that preserves center position
  const handleZoomStep = useCallback((delta: number) => {
    setZoomScale((currentZoom) => {
      const newScale = Math.max(0.4, Math.min(2.5, Number((currentZoom + delta).toFixed(2))));
      if (newScale === currentZoom) return currentZoom;

      if (containerRef.current && pagesWrapperRef.current) {
        const container = containerRef.current;
        const wrapper = pagesWrapperRef.current;
        const midInContainerX = container.clientWidth / 2;
        const midInContainerY = container.clientHeight / 2;

        const rectW = wrapper.getBoundingClientRect();
        const rectC = container.getBoundingClientRect();
        const wrapperScrollX = rectW.left - rectC.left + container.scrollLeft;
        const wrapperScrollY = rectW.top - rectC.top + container.scrollTop;

        const localX = container.scrollLeft + midInContainerX - wrapperScrollX;
        const localY = container.scrollTop + midInContainerY - wrapperScrollY;
        const ratio = newScale / currentZoom;

        pendingPinchCommitRef.current = {
          localX,
          localY,
          ratio,
          midInContainerX,
          midInContainerY,
        };
      }
      return newScale;
    });
  }, []);

  // Fit page width to current container
  const handleFitWidth = useCallback(() => {
    if (containerRef.current) {
      const containerW = containerRef.current.clientWidth;
      const targetPadding = window.innerWidth < 640 ? 24 : 48;
      const fitScale = Math.max(0.4, Math.min(2.0, (containerW - targetPadding) / 595));
      setZoomScale(Number(fitScale.toFixed(2)));
    } else {
      setZoomScale(1.0);
    }
  }, []);

  // Auto fit width when PDF finishes loading on mobile
  useEffect(() => {
    if (!isLoadingPdf && numPages > 0) {
      if (typeof window !== "undefined" && window.innerWidth < 640) {
        handleFitWidth();
      }
    }
  }, [isLoadingPdf, numPages, handleFitWidth]);

  // Load PDF Document when pdfBase64 changes
  useEffect(() => {
    if (!isOpen || !pdfBase64) return;

    if (lastLoadedPdfRef.current === pdfBase64 && pdfDocRef.current) {
      return;
    }
    lastLoadedPdfRef.current = pdfBase64;

    let isMounted = true;
    setIsLoadingPdf(true);
    setPageStrokes({});

    const loadDocument = async () => {
      try {
        const byteCharacters = atob(pdfBase64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        const loadingTask = pdfjsLib.getDocument({ data: byteArray });
        const doc = await loadingTask.promise;

        if (isMounted) {
          pdfDocRef.current = doc;
          setNumPages(doc.numPages);

          // Extract base page dimensions
          const dims: Record<number, { width: number; height: number }> = {};
          for (let p = 1; p <= doc.numPages; p++) {
            const page = await doc.getPage(p);
            const vp = page.getViewport({ scale: 1 });
            dims[p] = { width: vp.width, height: vp.height };
          }
          if (isMounted) {
            setPageDimensions(dims);
            setIsLoadingPdf(false);
          }
        }
      } catch (err) {
        console.error("Fehler beim Laden des PDFs in PDF.js:", err);
        if (isMounted) {
          setIsLoadingPdf(false);
        }
      }
    };

    loadDocument();

    return () => {
      isMounted = false;
    };
  }, [isOpen, pdfBase64]);

  // Redraw strokes on a specific drawing canvas
  const redrawPageStrokes = useCallback(
    (pageNum: number, strokes: Stroke[]) => {
      const canvas = drawingCanvasesRef.current[pageNum];
      if (!canvas || canvas.width === 0 || canvas.height === 0) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      renderStrokesToCanvas(ctx, strokes, canvas.width, canvas.height);
    },
    []
  );

  // Multi-touch pinch-to-zoom, Safari gesture block, and Ctrl+Wheel listener on containerRef
  useEffect(() => {
    const container = containerRef.current;
    if (!container || !isOpen) return;

    let touchStartDist = 0;
    let touchStartZoom = 1;
    let touchStartRectW: DOMRect | null = null;
    let touchLocalX = 0;
    let touchLocalY = 0;
    let lastMidInContainerX = 0;
    let lastMidInContainerY = 0;
    let currentScaleFactor = 1;
    let isPinching = false;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length >= 2) {
        if (e.cancelable) e.preventDefault();

        // If currently drawing, cancel current stroke immediately and remove stray mark
        if (isDrawingRef.current && currentStrokeRef.current) {
          const pageToClean = currentStrokeRef.current.pageNum;
          isDrawingRef.current = false;
          currentStrokeRef.current = null;
          redrawPageStrokes(pageToClean, pageStrokesRef.current[pageToClean] || []);
        }

        const t0 = e.touches[0];
        const t1 = e.touches[1];
        const dist = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
        const midX = (t0.clientX + t1.clientX) / 2;
        const midY = (t0.clientY + t1.clientY) / 2;

        const wrapper = pagesWrapperRef.current;
        if (!wrapper) return;

        wrapper.style.transform = "";
        wrapper.style.transformOrigin = "0 0";

        const rectW = wrapper.getBoundingClientRect();
        const rectC = container.getBoundingClientRect();

        touchStartDist = Math.max(dist, 10);
        touchStartZoom = zoomScale;
        touchStartRectW = rectW;
        touchLocalX = midX - rectW.left;
        touchLocalY = midY - rectW.top;
        lastMidInContainerX = midX - rectC.left;
        lastMidInContainerY = midY - rectC.top;
        currentScaleFactor = 1;
        isPinching = true;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isPinching || e.touches.length < 2 || !touchStartRectW) return;
      if (e.cancelable) e.preventDefault();

      const t0 = e.touches[0];
      const t1 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
      const midX = (t0.clientX + t1.clientX) / 2;
      const midY = (t0.clientY + t1.clientY) / 2;

      const rawScale = dist / touchStartDist;
      const s = Math.max(0.4 / touchStartZoom, Math.min(2.5 / touchStartZoom, rawScale));
      currentScaleFactor = s;

      const rectC = container.getBoundingClientRect();
      lastMidInContainerX = midX - rectC.left;
      lastMidInContainerY = midY - rectC.top;

      const tx = midX - touchStartRectW.left - touchLocalX * s;
      const ty = midY - touchStartRectW.top - touchLocalY * s;

      const wrapper = pagesWrapperRef.current;
      if (wrapper) {
        wrapper.style.transformOrigin = "0 0";
        wrapper.style.transform = `translate3d(${tx}px, ${ty}px, 0) scale(${s})`;
      }
    };

    const onTouchEnd = (e: TouchEvent) => {
      if (!isPinching) return;

      if (e.touches.length < 2) {
        isPinching = false;
        lastPinchEndTimeRef.current = Date.now();

        const finalZoom = Math.max(0.4, Math.min(2.5, Number((touchStartZoom * currentScaleFactor).toFixed(2))));
        const ratio = finalZoom / touchStartZoom;

        pendingPinchCommitRef.current = {
          localX: touchLocalX,
          localY: touchLocalY,
          ratio,
          midInContainerX: lastMidInContainerX,
          midInContainerY: lastMidInContainerY,
        };

        setZoomScale(finalZoom);
      }
    };

    const preventDefaultGesture = (e: Event) => {
      if (e.cancelable) e.preventDefault();
    };

    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.cancelable) e.preventDefault();
        const delta = e.deltaY < 0 ? 0.15 : -0.15;
        handleZoomStep(delta);
      }
    };

    container.addEventListener("touchstart", onTouchStart, { passive: false });
    container.addEventListener("touchmove", onTouchMove, { passive: false });
    container.addEventListener("touchend", onTouchEnd, { passive: false });
    container.addEventListener("touchcancel", onTouchEnd, { passive: false });
    container.addEventListener("gesturestart", preventDefaultGesture, { passive: false });
    container.addEventListener("gesturechange", preventDefaultGesture, { passive: false });
    container.addEventListener("gestureend", preventDefaultGesture, { passive: false });
    container.addEventListener("wheel", onWheel, { passive: false });

    return () => {
      container.removeEventListener("touchstart", onTouchStart);
      container.removeEventListener("touchmove", onTouchMove);
      container.removeEventListener("touchend", onTouchEnd);
      container.removeEventListener("touchcancel", onTouchEnd);
      container.removeEventListener("gesturestart", preventDefaultGesture);
      container.removeEventListener("gesturechange", preventDefaultGesture);
      container.removeEventListener("gestureend", preventDefaultGesture);
      container.removeEventListener("wheel", onWheel);
    };
  }, [isOpen, zoomScale, redrawPageStrokes, handleZoomStep]);

  // 1. Render PDF pages onto PDF canvases (when PDF loads or zoom changes)
  useEffect(() => {
    if (!pdfDocRef.current || numPages === 0 || isLoadingPdf) return;

    let isCancelled = false;

    const renderPages = async () => {
      for (let pageNum = 1; pageNum <= numPages; pageNum++) {
        if (isCancelled) break;
        try {
          const page = await pdfDocRef.current.getPage(pageNum);
          const pdfCanvas = pageCanvasesRef.current[pageNum];
          const drawCanvas = drawingCanvasesRef.current[pageNum];

          if (!pdfCanvas || !drawCanvas) continue;

          const pixelRatio = Math.max(window.devicePixelRatio || 1, 2);
          const viewport = page.getViewport({ scale: zoomScale * pixelRatio });

          // Set internal canvas resolution (High DPI)
          pdfCanvas.width = viewport.width;
          pdfCanvas.height = viewport.height;
          drawCanvas.width = viewport.width;
          drawCanvas.height = viewport.height;

          // Set display CSS size
          const cssWidth = `${viewport.width / pixelRatio}px`;
          const cssHeight = `${viewport.height / pixelRatio}px`;
          pdfCanvas.style.width = cssWidth;
          pdfCanvas.style.height = cssHeight;
          drawCanvas.style.width = cssWidth;
          drawCanvas.style.height = cssHeight;

          // Redraw strokes IMMEDIATELY on this resized canvas so strokes never disappear!
          const strokes = pageStrokesRef.current[pageNum] || [];
          redrawPageStrokes(pageNum, strokes);

          const ctx = pdfCanvas.getContext("2d");
          if (ctx) {
            const renderContext = {
              canvasContext: ctx,
              viewport: viewport,
            };
            await page.render(renderContext as any).promise;
          }

          // Redraw again after PDF page render to ensure stroke layer is crisp
          redrawPageStrokes(pageNum, pageStrokesRef.current[pageNum] || []);
        } catch (err) {
          console.error(`Fehler beim Rendern von Seite ${pageNum}:`, err);
        }
      }

      if (!isCancelled) {
        for (let p = 1; p <= numPages; p++) {
          redrawPageStrokes(p, pageStrokesRef.current[p] || []);
        }
      }
    };

    renderPages();

    return () => {
      isCancelled = true;
    };
  }, [numPages, zoomScale, isLoadingPdf, redrawPageStrokes]);

  // 2. Redraw strokes on drawing canvases whenever pageStrokes state updates
  useEffect(() => {
    pageStrokesRef.current = pageStrokes;
    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      const strokes = pageStrokes[pageNum] || [];
      redrawPageStrokes(pageNum, strokes);
    }
  }, [numPages, pageStrokes, redrawPageStrokes]);

  // 3. Keep strokes visible whenever switching between "view" and "pen" modes
  useEffect(() => {
    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      redrawPageStrokes(pageNum, pageStrokesRef.current[pageNum] || []);
    }
  }, [toolMode, numPages, redrawPageStrokes]);

  // Pointer event handlers for drawing
  const getNormalizedPoint = (
    e: React.PointerEvent<HTMLCanvasElement>,
    canvas: HTMLCanvasElement
  ): NormalizedPoint => {
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;
    return {
      nx: Math.max(0, Math.min(1, clientX / rect.width)),
      ny: Math.max(0, Math.min(1, clientY / rect.height)),
    };
  };

  const handlePointerDown = (
    e: React.PointerEvent<HTMLCanvasElement>,
    pageNum: number
  ) => {
    if (toolMode === "view") return;
    if (Date.now() - lastPinchEndTimeRef.current < 300) return;

    const canvas = drawingCanvasesRef.current[pageNum];
    if (!canvas) return;

    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {}
    isDrawingRef.current = true;

    const normPt = getNormalizedPoint(e, canvas);
    const isEraser = toolMode === "eraser";

    // Width relative to standard A4 base width (~600pt)
    const widthRatio = strokeWidth / 600;

    const newStroke: Stroke = {
      points: [normPt],
      color: penColor,
      widthRatio,
      isEraser,
    };

    currentStrokeRef.current = { pageNum, stroke: newStroke };

    // Render dot immediately
    const ctx = canvas.getContext("2d");
    if (ctx) {
      const ptX = normPt.nx * canvas.width;
      const ptY = normPt.ny * canvas.height;
      const baseWidth = widthRatio * canvas.width;

      ctx.beginPath();
      if (isEraser) {
        ctx.globalCompositeOperation = "destination-out";
        ctx.arc(ptX, ptY, (baseWidth * 4) / 2, 0, Math.PI * 2);
        ctx.fillStyle = "#000000";
        ctx.fill();
      } else {
        ctx.globalCompositeOperation = "source-over";
        ctx.arc(ptX, ptY, baseWidth / 2, 0, Math.PI * 2);
        ctx.fillStyle = penColor;
        ctx.fill();
      }
      ctx.globalCompositeOperation = "source-over";
    }
  };

  const handlePointerMove = (
    e: React.PointerEvent<HTMLCanvasElement>,
    pageNum: number
  ) => {
    if (Date.now() - lastPinchEndTimeRef.current < 300) return;
    if (!isDrawingRef.current || !currentStrokeRef.current) return;
    if (currentStrokeRef.current.pageNum !== pageNum) return;

    const canvas = drawingCanvasesRef.current[pageNum];
    if (!canvas) return;

    const normPt = getNormalizedPoint(e, canvas);
    const stroke = currentStrokeRef.current.stroke;
    stroke.points.push(normPt);

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    const baseWidth = stroke.widthRatio * canvas.width;

    if (stroke.isEraser) {
      ctx.globalCompositeOperation = "destination-out";
      ctx.lineWidth = baseWidth * 4;
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = baseWidth;
    }

    const pts = stroke.points;
    if (pts.length >= 2) {
      const p1 = pts[pts.length - 2];
      const p2 = pts[pts.length - 1];
      ctx.beginPath();
      ctx.moveTo(p1.nx * canvas.width, p1.ny * canvas.height);
      ctx.lineTo(p2.nx * canvas.width, p2.ny * canvas.height);
      ctx.stroke();
    }

    ctx.globalCompositeOperation = "source-over";
  };

  const handlePointerUp = (
    e: React.PointerEvent<HTMLCanvasElement>,
    pageNum: number
  ) => {
    const canvas = drawingCanvasesRef.current[pageNum];
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {}
    }

    if (!isDrawingRef.current || !currentStrokeRef.current) return;
    if (currentStrokeRef.current.pageNum !== pageNum) return;

    isDrawingRef.current = false;
    const { stroke } = currentStrokeRef.current;
    currentStrokeRef.current = null;

    setPageStrokes((prev) => {
      const existing = prev[pageNum] || [];
      const updated = [...existing, stroke];
      redrawPageStrokes(pageNum, updated);
      return {
        ...prev,
        [pageNum]: updated,
      };
    });
  };

  const handlePointerCancel = (
    e: React.PointerEvent<HTMLCanvasElement>,
    pageNum: number
  ) => {
    const canvas = drawingCanvasesRef.current[pageNum];
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {}
    }
    if (isDrawingRef.current && currentStrokeRef.current) {
      isDrawingRef.current = false;
      currentStrokeRef.current = null;
      redrawPageStrokes(pageNum, pageStrokesRef.current[pageNum] || []);
    }
  };

  // Undo last stroke
  const handleUndo = useCallback(() => {
    let targetPage = -1;
    for (let p = numPages; p >= 1; p--) {
      if (pageStrokes[p] && pageStrokes[p].length > 0) {
        targetPage = p;
        break;
      }
    }
    if (targetPage === -1) return;

    setPageStrokes((prev) => {
      const existing = prev[targetPage] || [];
      const updated = existing.slice(0, -1);
      redrawPageStrokes(targetPage, updated);
      return {
        ...prev,
        [targetPage]: updated,
      };
    });
  }, [numPages, pageStrokes, redrawPageStrokes]);

  // Keyboard shortcut Ctrl+Z for undoing strokes in PDF modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        handleUndo();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, handleUndo]);

  // Clear all strokes
  const handleClearAll = () => {
    if (confirm("Möchtest du alle Zeichnungen & Unterschriften auf allen Seiten löschen?")) {
      setPageStrokes({});
      for (let p = 1; p <= numPages; p++) {
        const canvas = drawingCanvasesRef.current[p];
        if (canvas) {
          const ctx = canvas.getContext("2d");
          ctx?.clearRect(0, 0, canvas.width, canvas.height);
        }
      }
    }
  };

  const totalStrokesCount = Object.values(pageStrokes).reduce(
    (acc, strokes) => acc + (strokes?.length || 0),
    0
  );

  // Generate ultra high-res 300 DPI PDF with embedded signatures using pdf-lib
  const generateSignedPdfBase64 = async (): Promise<string> => {
    if (!pdfBase64) return "";
    if (totalStrokesCount === 0) return pdfBase64;

    try {
      const byteCharacters = atob(pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);

      const pdfDoc = await PDFDocument.load(byteArray);
      const pages = pdfDoc.getPages();

      // Render at 300 DPI (exportScale = 4.167 for 72pt to 300dpi)
      const exportScale = 4.167;

      for (let pageNum = 1; pageNum <= numPages; pageNum++) {
        const strokes = pageStrokes[pageNum];
        if (strokes && strokes.length > 0 && pageNum <= pages.length) {
          const page = pages[pageNum - 1];
          const pageWidth = page.getWidth();
          const pageHeight = page.getHeight();

          // Create high-res offscreen canvas
          const highResCanvas = document.createElement("canvas");
          highResCanvas.width = Math.round(pageWidth * exportScale);
          highResCanvas.height = Math.round(pageHeight * exportScale);

          const highResCtx = highResCanvas.getContext("2d");
          if (highResCtx) {
            highResCtx.imageSmoothingEnabled = true;
            highResCtx.imageSmoothingQuality = "high";
            renderStrokesToCanvas(
              highResCtx,
              strokes,
              highResCanvas.width,
              highResCanvas.height
            );

            const highResDataUrl = highResCanvas.toDataURL("image/png");
            const pngImage = await pdfDoc.embedPng(highResDataUrl);

            page.drawImage(pngImage, {
              x: 0,
              y: 0,
              width: pageWidth,
              height: pageHeight,
            });
          }
        }
      }

      const savedBytes = await pdfDoc.save();
      let binary = "";
      const len = savedBytes.byteLength;
      for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(savedBytes[i]);
      }
      return btoa(binary);
    } catch (err) {
      console.error("Fehler beim Zusammenführen der Unterschriften ins PDF:", err);
      return pdfBase64;
    }
  };

  const handleSaveClick = async () => {
    setIsProcessingSave(true);
    try {
      const finalBase64 = await generateSignedPdfBase64();
      onDownload(finalBase64);
    } finally {
      setIsProcessingSave(false);
    }
  };

  const handleUploadClick = async () => {
    setIsProcessingSave(true);
    try {
      const finalBase64 = await generateSignedPdfBase64();
      onUpload(finalBase64);
    } finally {
      setIsProcessingSave(false);
    }
  };

  if (!isOpen || !pdfBase64) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 dark:bg-black/85 backdrop-blur-xs p-2 sm:p-4 animate-fade-in select-none">
      <div className="bg-white dark:bg-zinc-900 w-full max-w-6xl h-[95vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 dark:border-zinc-800">
        {/* Top App Header */}
        <div className="px-3 sm:px-4 py-2.5 bg-slate-50 dark:bg-zinc-950 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center border border-transparent dark:border-emerald-800/40 shrink-0">
              <FileCheck className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-zinc-100 flex items-center gap-1.5 sm:gap-2 truncate">
                <span>PDF Protokoll</span>
                {totalStrokesCount > 0 && (
                  <span className="px-1.5 sm:px-2 py-0.5 text-[9px] sm:text-[10px] font-bold bg-violet-100 dark:bg-violet-950/80 text-[#4A227A] dark:text-violet-300 rounded-full border border-violet-200 dark:border-violet-800/50 shrink-0">
                    Signiert ({totalStrokesCount})
                  </span>
                )}
              </h2>
              <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-zinc-400 truncate">
                {numPages} {numPages === 1 ? "Seite" : "Seiten"} • {compilerUsed}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Download / Save Button */}
            <button
              type="button"
              onClick={handleSaveClick}
              disabled={isSaving || isProcessingSave || isLoadingPdf}
              className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-4 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-[#4A227A] to-[#6B3E9E] hover:opacity-95 text-white transition-all shadow-sm active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
            >
              {isSaving || isProcessingSave ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Download className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">PDF Herunterladen</span>
              <span className="sm:hidden">PDF</span>
            </button>

            {/* Upload to Server (Always visible on mobile & desktop) */}
            <button
              type="button"
              onClick={handleUploadClick}
              disabled={isSaving || isProcessingSave || isLoadingPdf}
              title="Auf den Server übertragen"
              className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold bg-violet-50 dark:bg-zinc-800 text-[#4A227A] dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-zinc-700/80 border border-violet-200 dark:border-zinc-700 transition-colors shadow-xs shrink-0 active:scale-98"
            >
              <CloudUpload className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Auf Server hochladen</span>
              <span className="md:hidden">Server</span>
            </button>

            {/* Export as Word (Desktop only, hidden on mobile) */}
            {onExportDocx && (
              <button
                type="button"
                onClick={onExportDocx}
                title="Als Word-Dokument (.docx) exportieren"
                className="hidden sm:flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 rounded-xl text-xs font-semibold bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-blue-50/60 dark:hover:bg-zinc-700/80 border border-slate-200 dark:border-zinc-700 hover:border-blue-300 dark:hover:border-blue-500/60 transition-colors shadow-xs group shrink-0"
              >
                <FileText className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:scale-105 transition-transform" />
                <span className="hidden md:inline">Als Word (.docx)</span>
                <span className="md:hidden">Word</span>
              </button>
            )}

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-zinc-200 hover:bg-slate-200/60 dark:hover:bg-zinc-800 rounded-xl transition-colors ml-0.5 shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Floating Drawing & Zoom Toolbar */}
        <div className="px-3 sm:px-4 py-2 bg-white dark:bg-zinc-900/95 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between gap-2 sm:gap-3 text-xs shadow-xs shrink-0 overflow-x-auto no-scrollbar touch-pan-x whitespace-nowrap scroll-smooth">
          {/* Left: Tools (View, Pen, Eraser) */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setToolMode("view")}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg font-medium transition-all shrink-0 ${
                toolMode === "view"
                  ? "bg-slate-200 dark:bg-zinc-700 text-slate-900 dark:text-white shadow-xs font-bold"
                  : "text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
              title="Verschieben & Ansicht: Dokument mit Maus oder Finger frei bewegen"
            >
              <Hand className="w-3.5 h-3.5" />
              <span>Verschieben</span>
            </button>

            <button
              type="button"
              onClick={() => setToolMode("pen")}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg font-medium transition-all shrink-0 ${
                toolMode === "pen"
                  ? "bg-[#4A227A] text-white shadow-xs font-bold"
                  : "text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
              title="Stift: Unterschreiben & Markieren"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>Unterschreiben</span>
            </button>

            <button
              type="button"
              onClick={() => setToolMode("eraser")}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg font-medium transition-all shrink-0 ${
                toolMode === "eraser"
                  ? "bg-amber-600 text-white shadow-xs font-bold"
                  : "text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-800"
              }`}
              title="Radiergummi"
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Radierer</span>
            </button>

            {/* Separator */}
            <div className="h-4 w-px bg-slate-200 dark:border-zinc-800 mx-1 shrink-0" />

            {/* Color Palette (Active in Pen mode) */}
            {toolMode === "pen" && (
              <div className="flex items-center gap-1.5 shrink-0 animate-in fade-in duration-150">
                {PEN_COLORS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setPenColor(c.hex)}
                    title={c.label}
                    className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-all ${
                      penColor === c.hex
                        ? "ring-2 ring-offset-2 ring-[#4A227A] dark:ring-violet-400 scale-110"
                        : "hover:scale-105 opacity-85 hover:opacity-100"
                    }`}
                    style={{ backgroundColor: c.hex }}
                  >
                    {penColor === c.hex && <Check className="w-3 h-3 text-white stroke-[3]" />}
                  </button>
                ))}

                {/* Stroke Width Selector */}
                <div className="flex items-center gap-1 ml-1.5 bg-slate-100 dark:bg-zinc-800 p-0.5 rounded-lg border border-slate-200 dark:border-zinc-700/60 shrink-0">
                  {STROKE_WIDTHS.map((w) => (
                    <button
                      key={w.id}
                      type="button"
                      onClick={() => setStrokeWidth(w.value)}
                      title={w.label}
                      className={`px-2 py-0.5 text-[11px] rounded-md font-medium shrink-0 transition-all ${
                        strokeWidth === w.value
                          ? "bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 shadow-xs font-bold"
                          : "text-slate-500 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-200"
                      }`}
                    >
                      {w.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Undo & Clear */}
            <div className="flex items-center gap-1 ml-1 shrink-0">
              <button
                type="button"
                onClick={handleUndo}
                disabled={totalStrokesCount === 0}
                className="p-1.5 text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-100 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                title="Letzten Strich rückgängig machen (Strg+Z)"
              >
                <Undo2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                disabled={totalStrokesCount === 0}
                className="p-1.5 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                title="Alle Zeichnungen löschen"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right: Zoom Controls */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0 ml-auto">
            <button
              type="button"
              onClick={() => handleZoomStep(-0.15)}
              className="p-1.5 text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-100 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg transition-colors shrink-0"
              title="Verkleinern"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-medium text-slate-600 dark:text-zinc-400 w-11 text-center select-none shrink-0 font-mono">
              {Math.round(zoomScale * 100)}%
            </span>
            <button
              type="button"
              onClick={() => handleZoomStep(0.15)}
              className="p-1.5 text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-100 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg transition-colors shrink-0"
              title="Vergrößern"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={handleFitWidth}
              className="p-1.5 text-slate-600 dark:text-zinc-400 hover:text-slate-900 dark:hover:text-zinc-100 hover:bg-slate-100 dark:hover:bg-zinc-800 rounded-lg transition-colors shrink-0"
              title="Auf Bildschirmbreite anpassen"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Scrollable PDF Pages View Area */}
        <div
          ref={containerRef}
          onPointerDown={handleContainerPointerDown}
          onPointerMove={handleContainerPointerMove}
          onPointerUp={handleContainerPointerUp}
          onPointerCancel={handleContainerPointerUp}
          className={`relative flex-1 bg-slate-200/70 dark:bg-zinc-950 p-2 sm:p-6 overflow-auto overscroll-contain select-none ${
            toolMode === "view" ? "cursor-grab active:cursor-grabbing" : ""
          }`}
          style={{ touchAction: toolMode === "view" ? "pan-x pan-y" : "none" }}
        >
          <div
            ref={pagesWrapperRef}
            className="flex flex-col items-center gap-4 sm:gap-6 min-w-fit w-fit mx-auto transition-none py-2"
            style={{ transformOrigin: "0 0", willChange: "transform" }}
          >
            {isLoadingPdf ? (
              <div className="m-auto flex flex-col items-center justify-center space-y-3 text-slate-500 dark:text-zinc-400 py-20">
                <Loader2 className="w-8 h-8 animate-spin text-[#4A227A] dark:text-violet-400" />
                <p className="text-sm font-medium">Lade PDF Seiten zur Vorschau...</p>
              </div>
            ) : (
              Array.from({ length: numPages }, (_, idx) => idx + 1).map((pageNum) => {
                const pWidth = Math.round((pageDimensions[pageNum]?.width || 595.28) * zoomScale);
                const pHeight = Math.round((pageDimensions[pageNum]?.height || 841.89) * zoomScale);
                return (
                  <div
                    key={pageNum}
                    className="relative bg-white shadow-xl rounded-sm border border-slate-300 dark:border-zinc-800 shrink-0 select-none overflow-hidden group min-w-fit"
                    style={{
                      width: pWidth > 0 ? `${pWidth}px` : undefined,
                      height: pHeight > 0 ? `${pHeight}px` : undefined,
                    }}
                  >
                    {/* Page Number Badge */}
                    <div className="absolute top-2 right-2 z-20 px-2 py-0.5 text-[10px] font-semibold bg-black/60 text-white rounded-md backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      Seite {pageNum} von {numPages}
                    </div>

                    {/* PDF Render Canvas */}
                    <canvas
                      ref={(el) => {
                        pageCanvasesRef.current[pageNum] = el;
                      }}
                      style={{
                        width: pWidth > 0 ? `${pWidth}px` : undefined,
                        height: pHeight > 0 ? `${pHeight}px` : undefined,
                      }}
                      className="block"
                    />

                    {/* Interactive Drawing Canvas */}
                    <canvas
                      ref={(el) => {
                        drawingCanvasesRef.current[pageNum] = el;
                      }}
                      style={{
                        width: pWidth > 0 ? `${pWidth}px` : undefined,
                        height: pHeight > 0 ? `${pHeight}px` : undefined,
                      }}
                      onPointerDown={(e) => handlePointerDown(e, pageNum)}
                      onPointerMove={(e) => handlePointerMove(e, pageNum)}
                      onPointerUp={(e) => handlePointerUp(e, pageNum)}
                      onPointerCancel={(e) => handlePointerCancel(e, pageNum)}
                      className={`absolute inset-0 z-10 touch-none ${
                        toolMode === "view"
                          ? "cursor-default pointer-events-none"
                          : "cursor-crosshair"
                      }`}
                    />
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Bottom Helper Bar */}
        <div className="px-3 sm:px-4 py-2 bg-slate-50 dark:bg-zinc-950 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="truncate">
              {toolMode === "pen"
                ? "Stift aktiv: Unterschreibe im PDF. Mit 2 Fingern verschieben & zoomen."
                : toolMode === "eraser"
                ? "Radierer aktiv: Klicke oder ziehe über Striche zum Entfernen."
                : "Verschieben aktiv: Ziehe mit 1 Finger, zoome mit 2 Fingern."}
            </span>
          </div>

          {/* Quick Action Toggle for Mobile */}
          <div className="flex items-center gap-1.5 shrink-0 ml-2">
            <button
              type="button"
              onClick={() => setToolMode(toolMode === "view" ? "pen" : "view")}
              className={`flex items-center gap-1 px-3 py-1 rounded-md text-[11px] font-medium transition-colors shrink-0 ${
                toolMode === "view"
                  ? "bg-[#4A227A] text-white hover:bg-[#3d1a66]"
                  : "bg-slate-200 dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 hover:bg-slate-300"
              }`}
            >
              <span>{toolMode === "view" ? "Stift wählen" : "Verschieben"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
